import pandas as pd
import category_encoders as ce

# https://towardsdatascience.com/an-easier-way-to-encode-categorical-features-d840ff6b3900

# https://stackabuse.com/ensemble-voting-classification-in-python-with-scikit-learn/


# Attribute Information:
#   1. Class Name: 2 (democrat, republican)
#   2. handicapped-infants: 2 (y,n)
#   3. water-project-cost-sharing: 2 (y,n)
#   4. adoption-of-the-budget-resolution: 2 (y,n)
#   5. physician-fee-freeze: 2 (y,n)
#   6. el-salvador-aid: 2 (y,n)
#   7. religious-groups-in-schools: 2 (y,n)
#   8. anti-satellite-test-ban: 2 (y,n)
#   9. aid-to-nicaraguan-contras: 2 (y,n)
#   10. mx-missile: 2 (y,n)
#   11. immigration: 2 (y,n)
#   12. synfuels-corporation-cutback: 2 (y,n)
#   13. education-spending: 2 (y,n)
#   14. superfund-right-to-sue: 2 (y,n)
#   15. crime: 2 (y,n)
#   16. duty-free-exports: 2 (y,n)
#   17. export-administration-act-south-africa: 2 (y,n)


def main():

    data = pd.read_csv("house-votes-84.data", header=None, na_values="?", sep=",")

    print("*** data seize ***")
    print("\nrows: {}".format(len(data.index)))
    print("cols: {}\n".format(len(data.columns)))

    data.columns = [
        "class-name",
        "handicapped-infants",
        "water-project-cost-sharing",
        "adoption-of-the-budget-resolution",
        "physician-fee-freeze",
        "el-salvador-aid",
        "religious-groups-in-schools",
        "anti-satellite-test-ban",
        "aid-to-nicaraguan-contras",
        "mx-missile",
        "immigration",
        "synfuels-corporation-cutback",
        "education-spending",
        "superfund-right-to-sue",
        "crime",
        "duty-free-exports",
        "export-administration-act-south-africa",
    ]

    print("*** missing values ***")
    print(data.isnull().sum(axis=0))

    data = data.drop(
        columns=["water-project-cost-sharing", "export-administration-act-south-africa"]
    )

    data = data.dropna()

    print("\nrows: {}".format(len(data.index)))
    print("cols: {}\n".format(len(data.columns)))

    # print(data.head(5))

    # for index, col in enumerate(data.columns):
    #     print("index: {} - col: {}".format(index, col))

    # Get a new clean dataframe
    data_encoded = data.select_dtypes(include=['object']).copy()

    # Specify the columns to encode then fit and transform
    encoder = ce.BackwardDifferenceEncoder(cols=data.columns[1:])
    encoder.fit_transform(data_encoded, verbose=1).iloc[:,8:14].head()


if __name__ == "__main__":
    main()